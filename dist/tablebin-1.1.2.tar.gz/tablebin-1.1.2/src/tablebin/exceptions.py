class TablebinException(Exception):
    pass
